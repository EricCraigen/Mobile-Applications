package com.example.pigdicerollinggame

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView

internal class LeaderBoardadapter( private var leaderBoardList : List<LeaderBoardItem> ) :
        RecyclerView.Adapter<LeaderBoardadapter.MyViewHolder>() {
            internal inner class MyViewHolder(view : View) : RecyclerView.ViewHolder(view) {
                var item : TextView = view.findViewById(R.id.leaderBoardItemText)
        }

    @NonNull
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from( parent.context ).inflate(R.layout.leader_board_item, parent, false)
        return MyViewHolder( itemView )
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val leaderBoardItem = leaderBoardList.asReversed()[position]
        holder.item.text = leaderBoardItem.toString()
        var name = leaderBoardItem.toString().split(" ")
        if (name[0].length == 3) {
            holder.item.setTextColor(Color.BLUE)
        } else {
            holder.item.setTextColor(Color.RED)
        }
    }

    override fun getItemCount(): Int {
        return leaderBoardList.size
    }
}