package com.example.pigdicerollinggame

class LeaderBoardItem( var name : String, var score : Int, var date : String ) {
    fun toCSV() : String {
        return "$name,$score,$date"
    }

    override fun toString() : String {
        return if (name.length == 3) {
            "${name.padEnd(19)}:  $score    $date"
        } else {
            "$name     :  $score    $date"
        }
    }

}