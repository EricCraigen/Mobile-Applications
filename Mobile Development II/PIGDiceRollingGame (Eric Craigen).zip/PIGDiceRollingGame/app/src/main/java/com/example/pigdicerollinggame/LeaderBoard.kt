package com.example.pigdicerollinggame

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter

const val PIG_LEADER_BOARD = "leaderboard.txt"

class LeaderBoard : AppCompatActivity() {
    var leaderBoardList = ArrayList<LeaderBoardItem>()
    private lateinit var leaderBoardListAdapter : LeaderBoardadapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_leader_board)

        val recyclerView : RecyclerView = findViewById(R.id.pigLeaderBoardRecycler)
        leaderBoardListAdapter = LeaderBoardadapter(leaderBoardList)

        recyclerView.layoutManager = LinearLayoutManager(applicationContext)
        recyclerView.itemAnimator = DefaultItemAnimator()
        recyclerView.adapter = leaderBoardListAdapter

        val extras = intent.extras
        if (extras != null) {
            val name = extras.getString("WinnerName")
            val score = extras.getInt("WinnerScore")
            val date = extras.getString("WinnerDate")

            val fileOutputStream : FileOutputStream = openFileOutput(PIG_LEADER_BOARD, MODE_APPEND)
            val leaderBoardFile = OutputStreamWriter( fileOutputStream )
            leaderBoardFile.write("$name,$score,$date\n")
            leaderBoardFile.close()
        }
        readLeaderBoardData()
    }

    private fun readLeaderBoardData() {
        val file = File(filesDir, PIG_LEADER_BOARD)
        if (file.exists()) {
            file.forEachLine {
                val parts = it.split(",")
                var leaderBoardItem = LeaderBoardItem(parts[0], parts[1].toInt(), parts[2])
                leaderBoardList.add(leaderBoardItem)
            }
            leaderBoardListAdapter.notifyDataSetChanged()
        }
    }

    fun showPlayGameOnClick(v : View){
        val intent = Intent(this, MainActivity::class.java)
        startActivity( intent )
    }
}