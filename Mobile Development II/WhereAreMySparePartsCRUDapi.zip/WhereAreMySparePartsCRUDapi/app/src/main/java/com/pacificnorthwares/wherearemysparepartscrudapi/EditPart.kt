package com.pacificnorthwares.wherearemysparepartscrudapi

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import java.time.LocalDateTime

class EditPart : BaseActivity() {

    lateinit var edtName : EditText
    lateinit var edtDescription : EditText
    lateinit var edtPrice : EditText
    lateinit var edtRating : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_part)

        edtName = findViewById(R.id.edtName)
        edtDescription = findViewById(R.id.edtDescription)
        edtPrice = findViewById(R.id.edtPrice)
        edtRating = findViewById(R.id.edtRating)

        var part = partsList[currentRecord]

        edtName.setText( part.name )
        edtDescription.setText( part.description )
        edtPrice.setText( part.price.toString() )
        edtRating.setText( part.rating.toString() )
    }

    fun showAllPartsOnClick( v : View) {

        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun submitChangesOnClick( v : View) {

        var part = partsList[ currentRecord ]
        part.name = edtName.text.toString()
        part.description = edtDescription.text.toString()
        part.price = edtPrice.text.toString().toDouble()
        part.rating = edtRating.text.toString().toInt()
        part.updated_at = LocalDateTime.now().format(formatter)
        partsList[ currentRecord ] = part

        val queue = Volley.newRequestQueue(this)

        // Write the edited event to the Online database:
        val request : StringRequest = object : StringRequest(
            Method.PUT,
            "$baseUrl/${part.id}",
            Response.Listener { response ->
                // Your Response
                Log.i("CRUDapi", response)
            },
            Response.ErrorListener { error ->
                // Your Error
                Log.i("CRUDapi", "$error")
            }){
            override fun getParams() : MutableMap<String, String> {
                val params : MutableMap<String, String> = HashMap()
                params["name"] = part.name
                params["description"] = part.description
                params["price"] = part.price.toString()
                params["rating"] = part.rating.toString()
                params["created_at"] = part.created_at
                params["updated_at"] = part.updated_at
                return params
            }
        }

        // Add the request to the RequestQueue.
        request.setShouldCache(false)
        queue.add(request)

        toastIt("Part Updated Successfully")

//        writePartsListToFile()

        val intent = Intent(this, ShowPart::class.java)
        startActivity(intent)


    }
}