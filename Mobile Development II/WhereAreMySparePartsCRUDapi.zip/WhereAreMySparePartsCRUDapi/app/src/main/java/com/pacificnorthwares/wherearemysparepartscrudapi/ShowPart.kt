package com.pacificnorthwares.wherearemysparepartscrudapi

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley

class ShowPart : BaseActivity() {
    lateinit var part : PartsListItem
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_part)

        val txtPartName : TextView = findViewById(R.id.txtPartName)
        val txtPartDescription : TextView = findViewById(R.id.txtPartDescription)
        val txtPartSerialNum : TextView = findViewById(R.id.txtPartSerialNum)
        val txtDateAdded : TextView = findViewById(R.id.txtDateAdded)
        val txtPartLocation : TextView = findViewById(R.id.txtRating)
        val txtDateUpdated : TextView = findViewById(R.id.txtDateUpdated)

        part = partsList[currentRecord]

        txtPartName.text = part.name
        txtPartDescription.text = part.description
        txtPartSerialNum.text = part.price.toString()
        txtDateAdded.text = part.created_at
        txtPartLocation.text = part.rating.toString()
        txtDateUpdated.text = part.updated_at
    }

    fun editPartRecordOnClick( v : View) {
        val intent = Intent(this, EditPart::class.java)
        startActivity(intent)
    }

    fun showAllPartsOnClick( v : View) {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun deletePartOnClick( v : View) {
        val builder = android.app.AlertDialog.Builder(this)
        builder.setMessage("Are you sure you want to delete this event?")
            .setCancelable(false)
            .setPositiveButton("Yes") { dialog, which ->
                partsList.removeAt( currentRecord )

                // Instantiate the RequestQueue.
                val queue = Volley.newRequestQueue(this)

                // Request a jsonRequestObject as a response from the provided URL.
                val jsonObjectRequest = JsonObjectRequest(
                    Request.Method.DELETE,
                    "$baseUrl/${part.id}",
                    null, // jsonRequestObject
                    { response ->
                        // Display the first 500 characters of the response string.
                        Log.i("CRUDapi", "Response is: $response")
                    },
                    {
                        Log.i("CRUDapi", "It no worky - ${it.message}")
                    })

                // Add the request to the RequestQueue
                jsonObjectRequest.setShouldCache(false)
                queue.add(jsonObjectRequest)

                toastIt("Part Record Deleted Successfully")
//                writePartsListToFile()

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
            .setNegativeButton("No") { dialog, which ->
                toastIt("Record Deletion canceled")
                dialog.cancel()
            }
            .create()
            .show()
    }
}