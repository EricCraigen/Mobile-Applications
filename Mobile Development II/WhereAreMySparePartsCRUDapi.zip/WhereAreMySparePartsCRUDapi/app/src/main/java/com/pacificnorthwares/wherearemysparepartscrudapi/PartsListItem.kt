package com.pacificnorthwares.wherearemysparepartscrudapi

class PartsListItem( var id : Int, var name : String, var description : String, var price : Double, var rating : Int, var created_at : String, var updated_at : String) {

    fun toCSV() : String {
        return  "$name,$description,$price,$rating,$created_at,$updated_at"
    }

    override fun toString(): String {
        return "$name : $description : $price"
    }



}