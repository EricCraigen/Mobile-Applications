package com.pacificnorthwares.wherearemysparepartscrudapi

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import java.time.LocalDateTime

class MainActivity : BaseActivity() {

    lateinit var recyclerView : RecyclerView
    private lateinit var partsListAdapter : PartsAdapter
    private lateinit var seedDbBtn : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        seedDbBtn = findViewById(R.id.btnSeedDb)

        recyclerView = findViewById(R.id.partsRecycler)
        partsListAdapter = PartsAdapter(partsList) { position ->

            val intent = Intent(this, ShowPart::class.java)
            currentRecord = position
            startActivity(intent)
        }

        recyclerView.layoutManager = LinearLayoutManager(applicationContext)
        recyclerView.itemAnimator = DefaultItemAnimator()
        recyclerView.adapter = partsListAdapter

//        readPartsListFile()
//        if ( partsList.size === 0 ) {
//            seedDbBtn.visibility = View.VISIBLE
//        } else {
//            seedDbBtn.visibility = View.INVISIBLE
//        }
        partsListAdapter.notifyDataSetChanged()

        val queue = Volley.newRequestQueue(this)

        val stringRequest = JsonArrayRequest(
            Request.Method.GET,
            baseUrl,
            null, // jsonRequestObject
            { response ->

                for (i in 0 until response.length()) {
                    val event: JSONObject = response.getJSONObject(i)
                    val id = event.getInt("id")
                    val name = event.getString("name")
                    val description = event.getString("description")
                    val price = event.getDouble("price")
                    val rating = event.getInt("rating")
                    val startDate = event.getString("created_at")
                    val endDate = event.getString("updated_at")

                    val partsListItem = PartsListItem( id, name, description, price, rating, startDate, endDate )
                    partsList.add(partsListItem)

                }
                partsListAdapter.notifyDataSetChanged()


                // Display the first 500 characters of the response string.
                Log.i("CRUDapi", "Response is: $response")
            },
            {
                Log.i("CRUDapi", "It no worky - ${it.message}")
            })

        // Add the request to the RequestQueue
        stringRequest.setShouldCache(false)
        queue.add(stringRequest)

    }

    fun newRecordBtnClicked(v: View) {

        val intent = Intent(this, AddPart::class.java)
        startActivity(intent)
    }

//    fun seedPartsList(v: View) {
//
//        var partNames = ArrayList<String>()
//        var partDescriptions = ArrayList<String>()
//        var partSerialNums = ArrayList<String>()
//        var partLocations = ArrayList<String>()
//
//        partNames.add("GTX 1080Ti")
//        partNames.add("i7 8700 6c 12t")
//        partNames.add("LG Ultragear 27\" IPS G-SYNC")
//        partNames.add("HP690 Ryzen 7 1700, 16Gb DDR4, GTX 1060 3Gb")
//        partNames.add("Razer Huntsman Elite")
//        partNames.add("GTX 1060")
//        partNames.add("i5 8400 6c 6t")
//        partNames.add("ASUS 27\" OLED G-SYNC")
//        partNames.add("Corsair RM850X PSU")
//        partNames.add("Seagate Ironwolf 4Tb Mechanical HD")
//
//        partDescriptions.add("Graphics Card")
//        partDescriptions.add("Processor")
//        partDescriptions.add("Monitor")
//        partDescriptions.add("Desktop PC")
//        partDescriptions.add("KeyBoard")
//        partDescriptions.add("Mouse")
//        partDescriptions.add("Power Supply")
//        partDescriptions.add("USB Stick")
//        partDescriptions.add("Hard Drive (Mechanical)")
//        partDescriptions.add("Thermal Paste")
//
//        partSerialNums.add("GTX18284929")
//        partSerialNums.add("IN4323423TEL")
//        partSerialNums.add("LG27IPS")
//        partSerialNums.add("HPLINUX2334")
//        partSerialNums.add("KB23-00934")
//        partSerialNums.add("GTX23423FDFD")
//        partSerialNums.add("IN43890354TEL")
//        partSerialNums.add("ASUS27OLED")
//        partSerialNums.add("PSU12344321")
//        partSerialNums.add("KB25-SDFERRF")
//
//        partLocations.add("SHED")
//        partLocations.add("CLOSET SHELF")
//        partLocations.add("DESKTOP")
//        partLocations.add("TOOLBOX C-2")
//        partLocations.add("D-4-2")
//        partLocations.add("SHED LEFT SIDE")
//        partLocations.add("???")
//        partLocations.add("TOOLBOX B-4")
//        partLocations.add("TOOLBOX A-6")
//        partLocations.add("D3-4A-L2")
//
//        for ((mockRecordIndex) in (1..40).withIndex()) {
//            var partsListItem = PartsListItem(
//                "${partNames.random()}",
//                "${partDescriptions.random()}",
//                "${partSerialNums.random()}",
//                "${LocalDateTime.now().format(formatter)}",
//                "${partLocations.random()}",
//                "N/A"
//            )
//            partsList.add(partsListItem)
//            partsListAdapter.notifyDataSetChanged()
//        }
//
//        seedDbBtn.visibility = View.INVISIBLE
//        toastIt("Mock Db Seeded")
////        writePartsListToFile()
//    }
}