package com.pacificnorthwares.wherearemysparepartscrudapi

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import java.time.LocalDateTime

class AddPart : BaseActivity() {

    lateinit var edtName : EditText
    lateinit var edtDescription : EditText
    lateinit var edtPrice : EditText
    lateinit var edtRating : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_part)

        edtName = findViewById(R.id.edtName)
        edtDescription = findViewById(R.id.edtDescription)
        edtPrice = findViewById(R.id.edtPrice)
        edtRating = findViewById(R.id.edtRating)
    }

    fun showAllPartsOnClick( v : View) {

        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun addNewPartOnClick( v : View) {
//        var partsListItem = PartsListItem(
//            edtPartName.text.toString(),
//            edtPartDescription.text.toString(),
//            edtPartSerialNum.text.toString(),
//            LocalDateTime.now().format(formatter),
//            edtPartLocation.text.toString(),
//            "N/A"
//        )
//        partsList.add( partsListItem )

        val queue = Volley.newRequestQueue(this)

        // Write the added event to the Online database:
        val request : StringRequest = object : StringRequest(
            Method.POST,
            "$baseUrl",
            Response.Listener { response ->
                // Your Response
                Log.i("CRUDapi", response)
            },
            Response.ErrorListener { error ->
                // Your Error
                Log.i("CRUDapi", "$error")
            }){
            override fun getParams() : MutableMap<String, String> {
                val params : MutableMap<String, String> = HashMap()
                params["name"] = edtName.text.toString()
                params["description"] = edtDescription.text.toString()
                params["price"] = edtPrice.text.toString()
                params["rating"] = edtRating.text.toString()
                params["create_at"] = LocalDateTime.now().format(formatter).toString()
                params["updated_at"] = LocalDateTime.now().format(formatter).toString()
                return params
            }
        }

        // Add the request to the RequestQueue.
        request.setShouldCache(false)
        queue.add(request)

        toastIt("Part Added Successfully")
//        appendNewPartToPartsListFile( partsListItem )

        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}