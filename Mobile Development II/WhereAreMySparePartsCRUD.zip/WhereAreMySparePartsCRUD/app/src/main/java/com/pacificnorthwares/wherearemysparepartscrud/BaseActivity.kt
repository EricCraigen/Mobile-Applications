package com.pacificnorthwares.wherearemysparepartscrud

import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

var partsList = ArrayList<PartsListItem>()
var currentRecord = 0
const val PARTS_LIST_FILE = "parts_list.txt"
val formatter : DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd h:mm:ss a")

open class BaseActivity() : AppCompatActivity() {

    open fun toastIt( msg : String? ) {
        Toast.makeText(
            applicationContext,
            msg, Toast.LENGTH_SHORT
        ).show()
    }

    private fun fileSaved() {
        toastIt("File Successfully Saved")
    }

    fun writePartsListToFile() {
        val fileOutputStream : FileOutputStream = openFileOutput(PARTS_LIST_FILE, MODE_PRIVATE)
        val eventFile = OutputStreamWriter(fileOutputStream)

        for ( part in partsList ) {
            eventFile.write( part.toCSV() + "\n" )
        }

        eventFile.close()
        fileSaved()
    }

    fun readPartsListFile() {
        partsList.clear()
        val file = File(filesDir, PARTS_LIST_FILE)
        if ( file.exists() ) {
            File(filesDir, PARTS_LIST_FILE).forEachLine {
                val partPieces = it.split(",")
                var part = PartsListItem( partPieces[0], partPieces[1], partPieces[2], partPieces[3], partPieces[4], partPieces[5] )
                partsList.add( part )
            }
        }
    }

    fun appendNewPartToPartsListFile( part : PartsListItem ) {
        val fileOutputStream : FileOutputStream = openFileOutput(PARTS_LIST_FILE, MODE_APPEND)
        val partsListFile = OutputStreamWriter(fileOutputStream)
        partsListFile.write("${part.toCSV()}\n")

        partsListFile.close()
        fileSaved()
    }
}