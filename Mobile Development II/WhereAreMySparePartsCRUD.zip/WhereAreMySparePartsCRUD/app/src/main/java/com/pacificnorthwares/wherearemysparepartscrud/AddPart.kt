package com.pacificnorthwares.wherearemysparepartscrud

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import java.time.LocalDateTime

class AddPart : BaseActivity() {

    lateinit var edtPartName : EditText
    lateinit var edtPartDescription : EditText
    lateinit var edtPartSerialNum : EditText
    lateinit var edtPartLocation : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_part)

        edtPartName = findViewById(R.id.edtPartName)
        edtPartDescription = findViewById(R.id.edtPartDescription)
        edtPartSerialNum = findViewById(R.id.edtPartSerialNum)
        edtPartLocation = findViewById(R.id.edtLocation)
    }

    fun showAllPartsOnClick( v : View) {

        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun addNewPartOnClick( v : View) {
        var partsListItem = PartsListItem(
            edtPartName.text.toString(),
            edtPartDescription.text.toString(),
            edtPartSerialNum.text.toString(),
            LocalDateTime.now().format(formatter),
            edtPartLocation.text.toString(),
            "N/A"
        )
        partsList.add( partsListItem )

        toastIt("Part Added Successfully")
        appendNewPartToPartsListFile( partsListItem )

        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}