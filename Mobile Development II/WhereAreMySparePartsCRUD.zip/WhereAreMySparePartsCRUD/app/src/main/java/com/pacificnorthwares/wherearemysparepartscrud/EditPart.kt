package com.pacificnorthwares.wherearemysparepartscrud

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import java.time.LocalDateTime

class EditPart : BaseActivity() {

    lateinit var edtPartName : EditText
    lateinit var edtPartDescription : EditText
    lateinit var edtPartSerialNum : EditText
    lateinit var edtPartLocation : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_part)

        edtPartName = findViewById(R.id.edtPartName)
        edtPartDescription = findViewById(R.id.edtPartDescription)
        edtPartSerialNum = findViewById(R.id.edtPartSerialNum)
        edtPartLocation = findViewById(R.id.edtLocation)

        var part = partsList[currentRecord]

        edtPartName.setText( part.partName )
        edtPartDescription.setText( part.partDescription )
        edtPartSerialNum.setText( part.partSerialNum )
        edtPartLocation.setText( part.partLocation )
    }

    fun showAllPartsOnClick( v : View) {

        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun submitChangesOnClick( v : View) {

        var part = partsList[ currentRecord ]
        part.partName = edtPartName.text.toString()
        part.partDescription = edtPartDescription.text.toString()
        part.partSerialNum = edtPartSerialNum.text.toString()
        part.partLocation = edtPartLocation.text.toString()
        part.dateUpdated = LocalDateTime.now().format(formatter)

        partsList[ currentRecord ] = part

        toastIt("Part Updated Successfully")

        writePartsListToFile()

        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)


    }
}