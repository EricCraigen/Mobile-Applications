package com.pacificnorthwares.wherearemysparepartscrud

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

internal class PartsAdapter(private var partsList : List<PartsListItem>,
                             private val listener : (position : Int) -> Unit ) :
    RecyclerView.Adapter<PartsAdapter.MyViewHolder>() {

    inner class MyViewHolder( view : View) : RecyclerView.ViewHolder(view),
        View.OnClickListener {
        var partName : TextView = view.findViewById(R.id.tvPartItemName)
        var partDescription : TextView = view.findViewById(R.id.tvPartItemDescription)
        var partSerialNum : TextView = view.findViewById(R.id.tvPartItemSerialNum)
        var dateAdded : TextView = view.findViewById(R.id.tvPartItemDateAdded)
        var partLocation : TextView = view.findViewById(R.id.tvPartItemLocation)
        var dateUpdated : TextView = view.findViewById(R.id.tvPartItemDateUpdated)

        init {
            itemView.setOnClickListener( this )
        }

        override fun onClick( v : View) {
            listener( adapterPosition )
        }
    }

    override fun onCreateViewHolder(parent : ViewGroup, viewType : Int ) : MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.parts_list_item, parent, false)
        return MyViewHolder( itemView )
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val partsListItem = partsList[position]
        holder.partName.text = "${partsListItem.partName}"
        holder.partDescription.text = "${partsListItem.partDescription}"
        holder.partSerialNum.text =   "${partsListItem.partSerialNum}"
        holder.dateAdded.text =       "${partsListItem.dateAdded}"
        holder.partLocation.text = "${partsListItem.partLocation}"
        holder.dateUpdated.text = "${partsListItem.dateUpdated}"
    }

    override fun getItemCount(): Int {
        return partsList.size
    }
}