package com.pacificnorthwares.wherearemysparepartscrud

class PartsListItem( var partName : String, var partDescription : String, var partSerialNum : String, var dateAdded : String, var partLocation : String, var dateUpdated : String) {

    fun toCSV() : String {
        return  "$partName,$partDescription,$partSerialNum,$dateAdded,$partLocation,$dateUpdated"
    }

    override fun toString(): String {
        return "$partName : $partSerialNum : $partLocation"
    }



}