package com.pacificnorthwares.wherearemysparepartscrud

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast

class ShowPart : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_part)

        val txtPartName : TextView = findViewById(R.id.txtPartName)
        val txtPartDescription : TextView = findViewById(R.id.txtPartDescription)
        val txtPartSerialNum : TextView = findViewById(R.id.txtPartSerialNum)
        val txtDateAdded : TextView = findViewById(R.id.txtDateAdded)
        val txtPartLocation : TextView = findViewById(R.id.txtLocation)
        val txtDateUpdated : TextView = findViewById(R.id.txtDateUpdated)

        var part = partsList[currentRecord]

        txtPartName.text = part.partName
        txtPartDescription.text = part.partDescription
        txtPartSerialNum.text = part.partSerialNum
        txtDateAdded.text = part.dateAdded
        txtPartLocation.text = part.partLocation
        txtDateUpdated.text = part.dateUpdated
    }

    fun editPartRecordOnClick( v : View) {
        val intent = Intent(this, EditPart::class.java)
        startActivity(intent)
    }

    fun showAllPartsOnClick( v : View) {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun deletePartOnClick( v : View) {
        val builder = android.app.AlertDialog.Builder(this)
        builder.setMessage("Are you sure you want to delete this event?")
            .setCancelable(false)
            .setPositiveButton("Yes") { dialog, which ->
                partsList.removeAt( currentRecord )
                toastIt("Part Record Deleted Successfully")
                writePartsListToFile()

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
            .setNegativeButton("No") { dialog, which ->
                toastIt("Record Deletion canceled")
                dialog.cancel()
            }
            .create()
            .show()
    }
}