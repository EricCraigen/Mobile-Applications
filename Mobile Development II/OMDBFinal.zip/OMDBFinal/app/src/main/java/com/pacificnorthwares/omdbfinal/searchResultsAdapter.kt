package com.pacificnorthwares.omdbfinal

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

internal class SearchResultsAdapter(private var searchResultsList : List<SearchResultItem>,
                            private val listener : (position : Int) -> Unit ) :
    RecyclerView.Adapter<SearchResultsAdapter.MyViewHolder>() {

    inner class MyViewHolder( view : View) : RecyclerView.ViewHolder(view),
        View.OnClickListener {
        var movieTitle : TextView = view.findViewById(R.id.tvSeachResultItemMovieTitle)
        var dateOfRelease : TextView = view.findViewById(R.id.tvSeachResultItemDateOfRelease)
        var imdbID : TextView = view.findViewById(R.id.tvSeachResultItemIMDbID)
        var type : TextView = view.findViewById(R.id.tvSeachResultItemType)

        init {
            itemView.setOnClickListener( this )
        }

        override fun onClick( v : View) {
            listener( adapterPosition )
        }
    }

    override fun onCreateViewHolder(parent : ViewGroup, viewType : Int ) : MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.search_result_item, parent, false)
        return MyViewHolder( itemView )
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val searchResultsListItem = searchResultsList[position]
        holder.movieTitle.text = searchResultsListItem.movieTitle
        holder.dateOfRelease.text = searchResultsListItem.dateOfRelease
        holder.imdbID.text = searchResultsListItem.imdbID
        holder.type.text = searchResultsListItem.type
    }

    override fun getItemCount(): Int {
        return searchResultsList.size
    }
}