package com.pacificnorthwares.omdbfinal

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.*
import org.json.JSONArray

class MainActivity : BaseActivity() {

    private lateinit var searchResultsAdapter : SearchResultsAdapter
    lateinit var searchResultsRecyclerView : RecyclerView
    lateinit var edtUserSearchInput : EditText
    lateinit var btnMoreResults : Button
    var lastRecord : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtUserSearchInput = findViewById(R.id.edtSearchInput)
        searchResultsRecyclerView = findViewById(R.id.searchResultsRecycler)
        btnMoreResults = findViewById(R.id.btnMoreResults)

        searchResultsAdapter = SearchResultsAdapter(searchResultsList) { position ->
            val intent = Intent(this, MovieInfoView::class.java)
            currentRecord = position
            startActivity( intent )
        }

        searchResultsRecyclerView.layoutManager = LinearLayoutManager(applicationContext)
        searchResultsRecyclerView.itemAnimator = DefaultItemAnimator()
        searchResultsRecyclerView.adapter = searchResultsAdapter

        searchResultsAdapter.notifyDataSetChanged()

        val queue = Volley.newRequestQueue(this)

        val stringRequest = JsonObjectRequest(
            Request.Method.GET,
            "$baseUrl/?s=$userSearchInput&apikey=$apiKey",
            null, // jsonRequestObject
            { response ->
                val searchResults : JSONArray = response.getJSONArray("Search")
                val tempTotalResults  = response.getString("totalResults")
                Log.i("OMDBFinal", "Search Results is: $tempTotalResults")
                for (i in 0 until searchResults.length()) {
                    val movie = searchResults.getJSONObject(i)
                    val id = i + 1
                    val movieTitle = movie.getString("Title")
                    val dateOfRelease = movie.getString("Year")
                    val runtime = "runtime"
                    val type = movie.getString("Type")
                    val poster = movie.getString("Poster")
                    val imdbID = movie.getString("imdbID")
                    val searchListItem = SearchResultItem( id, movieTitle, dateOfRelease, runtime, type, poster, imdbID,  )
                    searchResultsList.add(searchListItem)
                }
                searchResultsAdapter.notifyDataSetChanged()
                totalResults = tempTotalResults.toInt()
                toastIt("Results Received")
            },
            {
                Log.i("OMDBFinal", "It no worky - ${it.message}")
            })
        stringRequest.setShouldCache(false)
        queue.add(stringRequest)
    }

    fun getMoreResults( v : View ) {
        lastRecord = searchResultsList.size
        if (lastRecord < totalResults) {
            ++currentResultsPage + 1

            val queue = Volley.newRequestQueue(this)

            val stringRequest = JsonObjectRequest(
                Request.Method.GET,
                "$baseUrl/?s=$userSearchInput&apikey=$apiKey&page=$currentResultsPage",
                null, // jsonRequestObject
                { response ->
                    val searchResults: JSONArray = response.getJSONArray("Search")
                    for (i in 0 until searchResults.length()) {
                        val movie = searchResults.getJSONObject(i)
                        val id = i + 1
                        val movieTitle = movie.getString("Title")
                        val dateOfRelease = movie.getString("Year")
                        val runtime = "runtime"
                        val type = movie.getString("Type")
                        val poster = movie.getString("Poster")
                        val imdbID = movie.getString("imdbID")
                        val searchListItem = SearchResultItem(
                            id,
                            movieTitle,
                            dateOfRelease,
                            runtime,
                            type,
                            poster,
                            imdbID,
                        )
                        searchResultsList.add(searchListItem)
                    }
                    searchResultsAdapter.notifyDataSetChanged()
                },
                {
                    Log.i("OMDBFinal", "It no worky - ${it.message}")
                })
            stringRequest.setShouldCache(false)
            queue.add(stringRequest)
        } else  {
            btnMoreResults.isClickable = false
        }
        Handler().postDelayed({
            searchResultsRecyclerView.smoothScrollToPosition(lastRecord )
            toastIt("Results Updated")
        }, 750)

    }

    fun getSearchResults( v : View ) {
        btnMoreResults.isClickable = true
        searchResultsList.clear()
        totalResults = 0
        userSearchInput = edtUserSearchInput.text.toString()

        val queueNew = Volley.newRequestQueue(this)

        val stringRequest = JsonObjectRequest(
            Request.Method.GET,
            "$baseUrl/?s=$userSearchInput&apikey=$apiKey",
            null, // jsonRequestObject
            { response ->
                val searchResults : JSONArray = response.getJSONArray("Search")
                val tempTotalResults  = response.getString("totalResults")
                Log.i("OMDBFinal", "Search Results is: $searchResults")
                for (i in 0 until searchResults.length()) {
                    val movie = searchResults.getJSONObject(i)
                    val id = i + 1
                    val movieTitle = movie.getString("Title")
                    val dateOfRelease = movie.getString("Year")
                    val runtime = "runtime"
                    val type = movie.getString("Type")
                    val poster = movie.getString("Poster")
                    val imdbID = movie.getString("imdbID")

                    val searchListItem = SearchResultItem( id, movieTitle, dateOfRelease, runtime, type, poster, imdbID,  )
                    searchResultsList.add(searchListItem)

                }
                searchResultsAdapter.notifyDataSetChanged()
                totalResults = tempTotalResults.toInt()
                toastIt("Results Received")
            },
            {
                Log.i("OMDBFinal", "It no worky - ${it.message}")
            })
        stringRequest.setShouldCache(false)
        queueNew.add(stringRequest)
    }

    fun scrollToTop( v : View ) {
        searchResultsRecyclerView.smoothScrollToPosition(0)
    }

    fun scrollToBottom( v : View ) {
        searchResultsRecyclerView.smoothScrollToPosition(searchResultsList.size)
    }

}