package com.pacificnorthwares.omdbfinal

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.android.volley.Request
import com.android.volley.toolbox.ImageRequest
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley

class MovieInfoView : BaseActivity() {
    lateinit var imdbID : String
    lateinit var moviePoster : ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_info_view)

        val txtMovieTitle : TextView = findViewById(R.id.txtMovieTitle)
        val txtDateOfRelease : TextView = findViewById(R.id.txtDateOfRelease)
        val txtRuntime : TextView = findViewById(R.id.txtRuntime)
        val txtRating : TextView = findViewById(R.id.txtRating)
        val txtDirector : TextView = findViewById(R.id.txtDirector)
        val txtLanguages : TextView = findViewById(R.id.txtLanguages)
        val txtGenre : TextView = findViewById(R.id.txtGenre)
        val txtActors : TextView = findViewById(R.id.txtActors)
        val txtAwards : TextView = findViewById(R.id.txtAwards)
        val txtPlot : TextView = findViewById(R.id.txtPlot)
        moviePoster = findViewById(R.id.imgMoviePoster)

        imdbID = searchResultsList[currentRecord].imdbID

        val queue = Volley.newRequestQueue(this)

        val stringRequest = JsonObjectRequest(
            Request.Method.GET,
            "$baseUrl/?i=$imdbID&apikey=$apiKey",
            null, // jsonRequestObject
            { response ->
                var movieTitle = response.getString("Title")
                txtMovieTitle.text = movieTitle
                var dateOfRelease = response.getString("Released")
                txtDateOfRelease.text = dateOfRelease
                var runtime = response.getString("Runtime")
                txtRuntime.text = runtime
                var rating = response.getString("Rated")
                txtRating.text = rating
                var director = response.getString("Director")
                txtDirector.text = director
                var languages = response.getString("Language")
                txtLanguages.text = languages
                var genre = response.getString("Genre")
                txtGenre.text = genre
                var actors = response.getString("Actors")
                txtActors.text = actors
                var awards = response.getString("Awards")
                txtAwards.text = awards
                var plot = response.getString("Plot")
                txtPlot.text = plot
                var poster = response.getString("Poster")
                val imageRequest = ImageRequest(
                    poster,
                    {bitmap -> // response listener
                        moviePoster.setImageBitmap(bitmap)
                    },
                    0, // max width
                    0, // max height
                    ImageView.ScaleType.CENTER_CROP, // image scale type
                    Bitmap.Config.ARGB_8888, // decode config
                    {error-> // error listener
                        Log.i("OMDBFinal", "It no worky - $error")
                    }
                )
                VolleySingleton.getInstance(applicationContext)
                    .addToRequestQueue(imageRequest)
            },
            {
                Log.i("OMDBFinal", "It no worky - ${it.message}")
            })

        stringRequest.setShouldCache(false)
        queue.add(stringRequest)
    }

    fun getHomePage( v : View) {
        searchResultsList.clear()
        val intent = Intent(this, MainActivity::class.java)
        startActivity( intent )
    }
}