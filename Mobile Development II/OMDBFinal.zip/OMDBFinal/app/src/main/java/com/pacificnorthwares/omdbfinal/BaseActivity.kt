package com.pacificnorthwares.omdbfinal

import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

var searchResultsList = ArrayList<SearchResultItem>()
var currentRecord = 0
const val apiKey = "8af0e10d"
const val baseUrl = "https://www.omdbapi.com"
var searchTerms = mutableListOf("interstellar", "star wars", "lord of the rings", "james bond")
var userSearchInput = searchTerms.random()
var currentResultsPage = 1
var totalResults = 0

open class BaseActivity() : AppCompatActivity() {

    open fun toastIt( msg : String? ) {
        Toast.makeText(
            applicationContext,
            msg, Toast.LENGTH_SHORT
        ).show()
    }

}