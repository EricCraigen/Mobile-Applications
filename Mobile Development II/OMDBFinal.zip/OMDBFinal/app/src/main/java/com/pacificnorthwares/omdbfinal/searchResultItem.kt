package com.pacificnorthwares.omdbfinal

class SearchResultItem(var id : Int, var movieTitle : String, var dateOfRelease : String, var runtime : String, var type : String, var poster : String, var imdbID : String) {

    fun toCSV() : String {
        return "$id,$movieTitle,$dateOfRelease,$runtime,$type,$poster,$imdbID"
    }

    override fun toString() : String {
        return "Id: $id\n" +
                "Movie Title: $movieTitle\n " +
                "Date of Release: $dateOfRelease\n" +
                "Runtime: $runtime\n" +
                "Type: $type\n" +
                "Poster URL: $poster\n" +
                "OMDB_ID: $imdbID"
    }

}